# treehouse_fed_project5
Sass project

Checked for Mozilla Firefox, Google Chrome, Opera, Safari.
For defining media queries I used mixin method described by Landon Schropp in this article https://davidwalsh.name/write-media-queries-sass.
